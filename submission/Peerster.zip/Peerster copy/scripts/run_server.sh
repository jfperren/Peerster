./Peerster -gossipAddr=127.0.0.1:5010 -UIPort=8080 -name="Alice" -peers=127.0.0.1:5011 -server
