#!/bin/sh

# Reset in case getopts has been used previously in the shell.
OPTIND=1

# Initialize our own variables:
size=1
name="Alice"

for i in "$@"
do
case $i in
    s=*|--size=*)
    size="${i#*=}"
    shift # past argument=value
    ;;
    n=*|--name=*)
    name="${i#*=}"
    shift # past argument=value
    ;;
esac
done

# shift $((OPTIND-1))
#
# [ "${1:-}" = "--" ] && shift


echo $size
echo $name

# shift $((OPTIND-1))
#
# [ "${1:-}" = "--" ] && shift
#
# echo "verbose=$verbose, output_file='$output_file', Leftovers: $@"

# End of file
