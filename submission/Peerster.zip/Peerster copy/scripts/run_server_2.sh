./Peerster -gossipAddr=127.0.0.1:5011 -UIPort=8081 -name="Bob" -peers=127.0.0.1:5010 -server
