./Peerster -UIPort=8080 -gossipAddr=127.0.0.1:5000 -name=Alice -peers=127.0.0.1:5001 -simple
